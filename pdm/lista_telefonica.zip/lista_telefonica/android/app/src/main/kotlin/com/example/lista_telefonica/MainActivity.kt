package com.example.lista_telefonica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
