class ContactoModel {
  int? id;
  String? name;
  String? numberPhone;
  String? emailAddress;
  ContactoModel({this.id, this.name, this.numberPhone, this.emailAddress});

  Map<String, dynamic> toJson() {
    return {
      "id": this.id,
      "name": this.name,
      "numberPhone": this.numberPhone,
      "emailAddress": this.emailAddress
    };
  }

  factory ContactoModel.fromJson(Map<String, dynamic> json) {
    return ContactoModel(
        id: json["id"],
        name: json["name"],
        numberPhone: json["numberPhone"],
        emailAddress: json["emailAddress"]);
  }
}
