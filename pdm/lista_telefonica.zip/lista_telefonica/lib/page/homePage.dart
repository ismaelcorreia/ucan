import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lista_telefonica/bloc/contactoBloc.dart';
import 'package:lista_telefonica/components/body.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ContactoBloc, CounterState>(builder: (context, state) {
      return Scaffold(
        body: BodyAppComponent(),
        floatingActionButton: FloatingActionButton(
          onPressed: () {},
          child: const Icon(Icons.add),
        ),
      );
    });
  }
}
