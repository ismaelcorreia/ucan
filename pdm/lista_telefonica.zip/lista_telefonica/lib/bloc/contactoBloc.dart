import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:lista_telefonica/bloc/events/addContactoEvent.dart';
import 'package:lista_telefonica/bloc/events/contactoEvent.dart';
import 'package:lista_telefonica/bloc/states/contactoState.dart';
import 'package:lista_telefonica/controllers/contactoDump.dart';

class ContactoBloc extends Bloc<ContactoEvent, ContactoState> {
  ContactoBloc() : super(InitialState());

  @override
  Stream<ContactoState> mapEventToState(ContactoState event) async* {
    if (event is AddContactoEvent) {
      yield* _saveContacto(event);
    } else if (event is DecrementEvent) {
      yield* _decrementEvent(event);
    }
  }

  Stream<ContactoCriado> _saveContacto(AddContactoEvent event) async* {
    final listaContactos = await ContactoDump().getContactos();
    listaContactos.add(event.model);
    final result = await ContactoDump().saveContactos(listaContactos);
    yield ContactoCriado(result);
  }

  Stream<CounterState> _decrementEvent(DecrementEvent event) async* {
    yield ButtonClicked(event.counter - 1);
  }
}

abstract class CounterEvent extends Equatable {}

class IncrementEvent extends CounterEvent {
  final int counter;
  IncrementEvent(this.counter);

  @override
  List<Object?> get props => [counter];
}

class DecrementEvent extends CounterEvent {
  final int counter;
  DecrementEvent(this.counter);

  @override
  List<Object?> get props => [counter];
}

abstract class CounterState extends Equatable {}

class ButtonClicked extends CounterState {
  final int counter;
  ButtonClicked(this.counter);

  @override
  List<Object?> get props => [counter];
}

class InitialState extends ContactoState {
  InitialState();
  @override
  List<Object?> get props => [];
}
