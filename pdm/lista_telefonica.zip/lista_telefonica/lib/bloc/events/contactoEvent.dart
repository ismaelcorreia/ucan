import 'package:equatable/equatable.dart';

abstract class ContactoEvent extends Equatable {}
