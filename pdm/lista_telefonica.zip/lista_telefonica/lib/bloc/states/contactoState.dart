import 'package:equatable/equatable.dart';

abstract class ContactoState extends Equatable {}

class ContactoCriado extends ContactoState {
  final bool result;
  ContactoCriado(this.result);

  @override
  List<Object?> get props => [result];
}
