import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lista_telefonica/bloc/contactoBloc.dart';

class BodyAppComponent extends StatelessWidget {
  const BodyAppComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocListener<ContactoBloc, CounterState>(
      listener: (context, state) {},
      child: ListView(),
    );
  }
}
